package cn.bmob.imdemo.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

import cn.bmob.imdemo.adapter.base.BaseViewHolder;
import cn.bmob.imdemo.bean.College;

/**
 * Created by 张益达 on 2016/12/5.
 */
public class SearchCollegeAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{

    private List<College> colleges = new ArrayList<>();

    public SearchCollegeAdapter() {
    }

    public void setDatas(List<College> list) {
        colleges.clear();
        if (null != list) {
            colleges.addAll(list);
        }
    }

    /**获取用户
     * @param position
     * @return
     */
    public College getItem(int position){
        return colleges.get(position);
    }

    private OnRecyclerViewListener onRecyclerViewListener;

    public void setOnRecyclerViewListener(OnRecyclerViewListener onRecyclerViewListener) {
        this.onRecyclerViewListener = onRecyclerViewListener;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new SearchUserHolder(parent.getContext(), parent, onRecyclerViewListener);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ((BaseViewHolder)holder).bindData(colleges.get(position));
    }

    @Override
    public int getItemViewType(int position) {
        return 1;
    }

    @Override
    public int getItemCount() {
        return colleges.size();
    }
}

