package cn.bmob.imdemo.bean;

import cn.bmob.imdemo.db.NewCollege;
import cn.bmob.v3.BmobObject;

/**
 * Created by 张益达 on 2016/12/5.
 */
public class College extends BmobObject {

    private String avatar;

    public College(){}

    public College(NewCollege college){
        setObjectId(college.getUid());
//        setUsername(College.getName());
//        setAvatar(college.getAvatar());
    }

//    public String getAvatar() {
//        return avatar;
//    }

//    public void setAvatar(String avatar) {
//        this.avatar = avatar;
//    }
}
