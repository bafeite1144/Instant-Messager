package cn.bmob.imdemo.bean;

import android.support.annotation.NonNull;

import java.sql.Timestamp;

import cn.bmob.imdemo.db.NewFriend;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.datatype.BmobGeoPoint;

/**
 * @author :smile
 * @project:User
 * @date :2016-01-22-18:11
 */
public class User extends BmobUser implements Comparable<User>{

    private String avatar;
    private String name;
    private String address;

    private String sortedKey;
    private String sex;
    private String signature;
    private String birthDay;

    public User(){}

    public User(NewFriend friend){
        setObjectId(friend.getUid());
        setUsername(friend.getName());
        setAvatar(friend.getAvatar());


        setSex(friend.getSex());
        setSignature(friend.getSign());
        setAddress(friend.getAddress());
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }


    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }




    public String getSex() {
        return sex;
    }
    public void setSex(String sex) {
        this.sex = sex;
    }








    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public String getBirthDay() {
        return birthDay;
    }

    public void setBirthDay(String birthDay) {
        this.birthDay = birthDay;
    }

    private BmobGeoPoint location;

    public BmobGeoPoint getLocation() {
        return location;
    }

    public void setLocation(BmobGeoPoint location) {
        this.location = location;
    }
























    @Override
    public int compareTo(User another) {
        return getSortedKey().compareTo(another.getSortedKey());
    }

    public String getSortedKey() {
        return sortedKey;
    }


    public void setSortedKey(String sortedKey) {
        this.sortedKey = sortedKey;
    }
}
