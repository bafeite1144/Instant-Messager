package cn.bmob.imdemo.event;

/**
 * @author :smile
 * @project:FinishEvent
 * @date :2016-01-25-15:25
 */
public class FinishEvent {

    public FinishEvent(){}
}
