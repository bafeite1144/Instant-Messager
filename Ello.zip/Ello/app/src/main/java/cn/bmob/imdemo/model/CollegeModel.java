package cn.bmob.imdemo.model;

import java.util.List;

import cn.bmob.imdemo.bean.College;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.listener.FindListener;

/**
 * @author :smile
 * @project:UserModel
 * @date :2016-01-22-18:09
 */
public class CollegeModel extends BaseModel {

    private static CollegeModel ourInstance = new CollegeModel();

    public static CollegeModel getInstance() {
        return ourInstance;
    }

    private CollegeModel() {}

    /**查询用户
     * @param collegeName
     * @param limit
     * @param listener
     */
    public void queryColleges(String collegeName,int limit,final FindListener<College> listener){
        BmobQuery<College> query = new BmobQuery<>();
        //去掉当前用户

        query.addWhereContains("collegeName", collegeName);
        query.setLimit(limit);
        query.order("-createdAt");
        query.findObjects(getContext(), new FindListener<College>() {
            @Override
            public void onSuccess(List<College> list) {
                if (list != null && list.size() > 0) {
                    listener.onSuccess(list);
                } else {
                    listener.onError(CODE_NULL, "暂无此学校");
                }
            }

            @Override
            public void onError(int i, String s) {
                listener.onError(i, s);
            }
        });
    }
}
