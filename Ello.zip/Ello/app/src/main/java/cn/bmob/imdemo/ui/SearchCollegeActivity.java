package cn.bmob.imdemo.ui;

import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.List;

import butterknife.Bind;
import butterknife.OnClick;
import cn.bmob.imdemo.R;
import cn.bmob.imdemo.adapter.OnRecyclerViewListener;
import cn.bmob.imdemo.adapter.SearchCollegeAdapter;
import cn.bmob.imdemo.base.ParentWithNaviActivity;
import cn.bmob.imdemo.bean.College;
import cn.bmob.imdemo.model.BaseModel;
import cn.bmob.imdemo.model.CollegeModel;
import cn.bmob.v3.listener.FindListener;

/**搜索好友
 * @author :smile
 * @project:SearchUserActivity
 * @date :2016-01-25-18:23
 */
public class SearchCollegeActivity extends ParentWithNaviActivity {

    @Bind(R.id.et_find_college)
    EditText et_find_college;
    @Bind(R.id.sw_refresh_college)
    SwipeRefreshLayout sw_refresh_college;
    @Bind(R.id.btn_search_college)
    Button btn_search_college;
    @Bind(R.id.rc_view_college)
    RecyclerView rc_view_college;
    LinearLayoutManager layoutManager;
    SearchCollegeAdapter adapter;

    @Override
    protected String title() {
        return "选择院校";
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_college);
        initNaviView();
        adapter =new SearchCollegeAdapter();
        layoutManager = new LinearLayoutManager(this);
        rc_view_college.setLayoutManager(layoutManager);
        rc_view_college.setAdapter(adapter);
        sw_refresh_college.setEnabled(true);
        sw_refresh_college.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                query();
            }
        });
        adapter.setOnRecyclerViewListener(new OnRecyclerViewListener() {
            @Override
            public void onItemClick(int position) {
                Bundle bundle = new Bundle();
                College college = adapter.getItem(position);
                bundle.putSerializable("c", college);
//                startActivity(UserInfoActivity.class, bundle, false);
            }

            @Override
            public boolean onItemLongClick(int position) {
                return true;
            }
        });
    }

    @OnClick(R.id.btn_search_college)
    public void onSearchClick(View view){
        sw_refresh_college.setRefreshing(true);
        query();
    }

    public void query(){
        String collegeName =et_find_college.getText().toString();
        if(TextUtils.isEmpty(collegeName)){
            toast("请填写校名");
            sw_refresh_college.setRefreshing(false);
            return;
        }
        CollegeModel.getInstance().queryColleges(collegeName, BaseModel.DEFAULT_LIMIT, new FindListener<College>() {
            @Override
            public void onSuccess(List<College> list) {
                sw_refresh_college.setRefreshing(false);
                adapter.setDatas(list);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onError(int i, String s) {
                sw_refresh_college.setRefreshing(false);
                adapter.setDatas(null);
                adapter.notifyDataSetChanged();
                toast(s + "(" + i + ")");
            }
        });

    }



}
