package cn.bmob.imdemo.ui;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import butterknife.Bind;
import butterknife.OnClick;
import cn.bmob.imdemo.BmobIMApplication;
import cn.bmob.imdemo.R;
import cn.bmob.imdemo.base.ImageLoaderFactory;
import cn.bmob.imdemo.base.ParentWithNaviActivity;
import cn.bmob.imdemo.bean.AddFriendMessage;
import cn.bmob.imdemo.bean.User;
import cn.bmob.imdemo.manager.UserManager;
import cn.bmob.imdemo.util.PhotoUtil;
import cn.bmob.newim.BmobIM;
import cn.bmob.newim.bean.BmobIMConversation;
import cn.bmob.newim.bean.BmobIMMessage;
import cn.bmob.newim.bean.BmobIMUserInfo;
import cn.bmob.newim.core.BmobIMClient;
import cn.bmob.newim.listener.MessageSendListener;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.datatype.BmobFile;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.imdemo.base.Constant;
import cn.bmob.v3.listener.UpdateListener;
import cn.bmob.v3.listener.UploadFileListener;
import cn.bmob.imdemo.base.CommonImageLoader;

import static cn.bmob.imdemo.R.id.avatar;

/**
 * 用户资料
 */
public class UserInfoActivity extends ParentWithNaviActivity implements View.OnClickListener{

    @Bind(R.id.iv_avatar)
    ImageView iv_avatar;
//    @Bind(R.id.rl_edit_user_info_sex)
//    RelativeLayout sexLayout;
    private RelativeLayout avatarLayout, nickLayout, sexLayout, birthLayout, phoneLayout,
            emailLayout, signatureLayout, addressLayout;
    private TextView tv_name, tv_sex, tv_birth, tv_phone, tv_email, tv_signature, tv_address;

    User user;
    BmobIMUserInfo info;
    @Override
    protected String title() {
        return "个人资料";
    }

//    @Override
//    public Object right() {
//        return R.drawable.btn_edit;
//    }


    @Override
    public ParentWithNaviActivity.ToolBarListener setToolBarListener() {
        return new ParentWithNaviActivity.ToolBarListener() {
            @Override
            public void clickLeft() {

            }

            @Override
            public void clickRight() {
//                startActivity(EditUserInfoActivity.class,null, false);
            }
        };
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_info);
        initNaviView();
        user=(User)getBundle().getSerializable("u");

        //构造聊天方的用户信息:传入用户id、用户名和用户头像三个参数
        info = new BmobIMUserInfo(user.getObjectId(),user.getUsername(),user.getAvatar());
        ImageLoaderFactory.getLoader().loadAvator(iv_avatar,user.getAvatar(),R.mipmap.head);
        tv_name.setText(user.getUsername());


//        info = new BmobIMUserInfo(user.getSex(),user.getSignature(),user.getAddress());
//   BmobIMUserInfo info1 = new BmobIMUserInfo(user.getObjectId(), user.getAddress(), user.getEmail());
////        user = UserManager.getInstance().getCurrentUser();
//
////        tv_birth.setText(user.getBirthDay());
//        tv_phone.setText(user.getMobilePhoneNumber());
        tv_sex.setText(user.getSex());
////        tv_email.setText(user.getEmail());
//        tv_signature.setText(user.getSignature());
//        tv_address.setText(user.getAddress());
    }















    public void initView() {
//        avatarLayout = (RelativeLayout) findViewById(R.id.rl_edit_user_info_avatar);
//        nickLayout = (RelativeLayout) findViewById(R.id.rl_edit_user_info_nick);
//        sexLayout = (RelativeLayout) findViewById(R.id.rl_edit_user_info_sex);
//        birthLayout = (RelativeLayout) findViewById(R.id.rl_edit_user_info_birth);
//        phoneLayout = (RelativeLayout) findViewById(R.id.rl_edit_user_info_phone);
//        emailLayout = (RelativeLayout) findViewById(R.id.rl_edit_user_info_email);
//        signatureLayout = (RelativeLayout) findViewById(R.id.rl_edit_user_info_signature);
//        addressLayout = (RelativeLayout) findViewById(R.id.rl_edit_user_info_address);
        iv_avatar = (ImageView) findViewById(R.id.iv_avatar);
        tv_name = (TextView) findViewById(R.id.tv_name);
        tv_sex = (TextView) findViewById(R.id.tv_sex);
        tv_birth = (TextView) findViewById(R.id.tv_birth);
        tv_phone = (TextView) findViewById(R.id.tv_phone);
        tv_email = (TextView) findViewById(R.id.tv_email);
        tv_signature = (TextView) findViewById(R.id.tv_signature);
        tv_address = (TextView) findViewById(R.id.tv_address);
        iv_avatar.setOnClickListener(this);
        tv_name.setOnClickListener(this);
        tv_sex.setOnClickListener(this);
        tv_birth.setOnClickListener(this);
        tv_phone.setOnClickListener(this);
        tv_email.setOnClickListener(this);
        tv_signature.setOnClickListener(this);
//        addressLayout.setOnClickListener(this);
        tv_address.setOnClickListener(this);
    }







//    public void initData() {
//        mUser = UserManager.getInstance().getCurrentUser();
//        nick.setText(mUser.getNick());
//        birth.setText(mUser.getBirthDay());
//        phone.setText(mUser.getMobilePhoneNumber());
//        sex.setText(mUser.isSex() ? "男" : "女");
//        email.setText(mUser.getEmail());
//        signature.setText(mUser.getSignature());
//        address.setText(mUser.getAddress());
//        Glide.with(this).load(mUser.getAvatar()).into(avatar);
//        ToolBarOption toolBarOption = new ToolBarOption();
//        toolBarOption.setAvatar(null);
//        toolBarOption.setRightResId(R.drawable.ic_file_upload_blue_grey_900_24dp);
//        toolBarOption.setTitle("编辑个人资料");
//        toolBarOption.setRightListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (mUser.getAvatar() == null) {
//                    ToastUtils.showShortToast("请设置个人头像拉^_^");
//                    return;
//                }
//                Intent intent = new Intent();
//                intent.putExtra("user", mUser);
//                setResult(Activity.RESULT_OK, intent);
//                finish();
//            }
//        });
//        getBack().setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (mUser.getAvatar() == null) {
//                    ToastUtils.showShortToast("请设置个人头像拉^_^");
//                    return;
//                }
//                finish();
//            }
//        });
//        toolBarOption.setNeedNavigation(true);
//        setToolBar(toolBarOption);
//    }


    public void onClick(View v) {
        Intent intent = new Intent();
        switch (v.getId()) {
//            case R.id.iv_avatar:
////                CommonImageLoader.getInstance().initStanderConfig(1);
//                intent.setClass(this, SelectedPictureActivity.class);
//                startActivityForResult(intent, Constant.REQUEST_CODE_SELECT_PICTURE);
//                break;
            case R.id.tv_name:
                intent.putExtra("from", "nick");
                intent.putExtra("message", user.getUsername());
                intent.setClass(this, EditUserNameActivity.class);
                startActivityForResult(intent, Constant.REQUEST_CODE_NICK);
                break;
//            case R.id.tv_sex:
//                intent.putExtra("from", "gender");
//                intent.putExtra("message", user.getSex());
//                intent.setClass(this, EditUserInfoDetailActivity.class);
//                startActivityForResult(intent, Constant.REQUEST_CODE_SEX);
//                break;
//            case R.id.tv_birth:
//                intent.putExtra("from", "birth");
//                intent.putExtra("message", user.getBirthDay());
//                intent.setClass(this, EditUserInfoDetailActivity.class);
//                startActivityForResult(intent, Constant.REQUEST_CODE_BIRTH);
//                break;
//            case R.id.tv_phone:
//                intent.putExtra("from", "phone");
//                intent.putExtra("message", user.getMobilePhoneNumber());
//                intent.setClass(this, EditUserInfoDetailActivity.class);
//                startActivityForResult(intent, Constant.REQUEST_CODE_PHONE);
//                break;
//            case R.id.tv_email:
//                intent.putExtra("from", "email");
//                intent.putExtra("message", user.getEmail());
//                intent.setClass(this, EditUserInfoDetailActivity.class);
//                startActivityForResult(intent, Constant.REQUEST_CODE_EMAIL);
//                break;
            case R.id.tv_signature:
                intent.putExtra("from", "signature");
                intent.putExtra("message", user.getSignature());
                intent.setClass(this, EditUserSignatureActivity.class);
                startActivityForResult(intent, Constant.REQUEST_CODE_SIGNATURE);
                break;
            case R.id.tv_address:
                intent.putExtra("from", "address");
                intent.putExtra("message", user.getAddress());
                intent.setClass(this, EditUserAddressActivity.class);
                startActivityForResult(intent, Constant.REQUEST_CODE_ADDRESS);
//            default:

        }
    }



    @Override
    protected void onDestroy() {
        super.onDestroy();
        CommonImageLoader.getInstance().clearAllData();
    }


    @Override
    public void finish() {
//        LogUtil.e("editUserInfo_finish");
        Intent intent = new Intent();
        intent.putExtra("user", user);
        setResult(Activity.RESULT_OK, intent);
        super.finish();
    }

















}
